from django.db import models

class AudioManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(type='Audio')

class VideoManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(type='Video')

class ImageManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(type='Image')

class Media(models.Model):
    MEDIA_TYPES = [
        ('Audio', 'Audio'),
        ('Video', 'Video'),
        ('Image', 'Image'),
    ]
    
    name = models.CharField(max_length=255)
    type = models.CharField(max_length=10, choices=MEDIA_TYPES)
    format = models.CharField(max_length=10)
    size_mb = models.PositiveIntegerField()
    duration_secs = models.PositiveIntegerField(default=0)
    
    objects = models.Manager()  # The default manager
    audio = AudioManager()      # Custom manager for audio files
    video = VideoManager()      # Custom manager for video files
    image = ImageManager()      # Custom manager for image files
    
    def __str__(self):
        return self.name

