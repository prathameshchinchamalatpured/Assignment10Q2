from django.contrib import admin
from .models import Media

admin.site.register(Media)