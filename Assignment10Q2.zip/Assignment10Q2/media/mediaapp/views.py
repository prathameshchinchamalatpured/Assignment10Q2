from django.shortcuts import render,HttpResponse,redirect
from mediaapp.models import Media

# Create your views here.
def index(request):
    # Example of creating a new media object
    song1 = Media.objects.create(name='Song1', type='Audio', format='mp3', size_mb=10, duration_secs=5)
    song2 = Media.objects.create(name='Song2', type='Video', format='mp4', size_mb=200, duration_secs=5)
    image1 = Media.objects.create(name='Image1', type='Image', format='JPG', size_mb=4)

    # Retrieve all audio files
    audio_files = Media.audio.all()
    for a in audio_files:
        print(a)
    # Retrieve all video files
    video_files = Media.video.all()
    for a in video_files:
        print(a)
    # Retrieve all image files
    image_files = Media.image.all()
    for a in image_files:
        print(a)
    return HttpResponse("Objects Created")
    
    
