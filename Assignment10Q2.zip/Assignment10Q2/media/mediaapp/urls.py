from django.urls import path
from mediaapp import views
urlpatterns = [
    path('',views.index)
]
